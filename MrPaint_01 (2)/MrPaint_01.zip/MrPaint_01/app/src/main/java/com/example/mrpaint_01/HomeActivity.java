package com.example.mrpaint_01;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mrpaint_01.Model.JobType;
import com.example.mrpaint_01.Model.ServiceAdvisors;
import com.example.mrpaint_01.Model.User;
import com.example.mrpaint_01.Model.VehicleMake;
import com.example.mrpaint_01.Model.VehicleModel;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

//    List<VehicleMake> vehicleMakeList = new ArrayList<VehicleMake>();
//    ArrayList<String> vehicleMakeName = new ArrayList<>();
//    ArrayList<String> vehicleListID = new ArrayList<>();
//
//    ArrayList<VehicleModel> vehicleModelList = new ArrayList<VehicleModel>();
//    ArrayList<String> vehicleModelsName = new ArrayList<>();
//
//    List<JobType> jobType = new ArrayList<JobType>();
//    ArrayList<String> jobTypeName = new ArrayList<>();
//    ArrayList<String> jobId = new ArrayList<>();
//
//    List<ServiceAdvisors> serviceAdvisors = new ArrayList<ServiceAdvisors>();
//    ArrayList<String> serviceName = new ArrayList<>();
//    ArrayList<String> serviceId = new ArrayList<>();
//
//    String selectedItem;
//    String vehicleID;
//    String element;
//    String modelNo;
//    String serviceNo;
//
//    String jobID;
//    Button image;
//    UserService userService;
//    User user = new User();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
}
